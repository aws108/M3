import java.util.Scanner;


public class PruebaAccesoDatos {


	public static void main(String[] args) {
		
		AccesoDatos acc = new AccesoDatos();
		Scanner menu = new Scanner(System.in);
		int op;
		
		//Menu
	do{
		System.out.println("==================================================");
		System.out.println("========  Selecciona una opción  =================");
		System.out.println("==================================================");
		System.out.println("= Por defecto se abrirá la conexión y se cerrará =");
		System.out.println("==================================================");
		System.out.println("==================================================");
		System.out.println("= 1- Obtener registros de la tabla Coches ========");
		System.out.println("= 2- Listar Propietarios con sus coches   ========");
		System.out.println("= 3- Modificar el precio de un coche      ========");
		System.out.println("= 4- Eliminar un Coche                    ========");
		System.out.println("= 5- Insertar un coche                    ========");
		System.out.println("= 6- Lista coches y datos del propietario ========");
		System.out.println("==================================================");
		System.out.println("==================================================");
		System.out.println("= 7- Salir                                ========");
		System.out.println("==================================================");
		op = menu.nextInt();
		switch(op){
			case 1: acc.abrirConexion();
			acc.obtenerregistros();
					acc.cerrarConexion();
					break;
			case 2: acc.abrirConexion();
			acc.listarPropietarios();
					acc.cerrarConexion();
					break;
			case 3: acc.abrirConexion();
			acc.modificarPrecio();
					acc.cerrarConexion();
					break;
			case 4: acc.abrirConexion();
			acc.eliminarCoche();
					acc.cerrarConexion();
					break;
			case 5: acc.abrirConexion();
			acc.insertarCoche();
					acc.cerrarConexion();
					break;
			case 6: acc.abrirConexion();
			acc.listar();
					acc.cerrarConexion();
					break;
		}
	}while (op!=7);
			
	}

}